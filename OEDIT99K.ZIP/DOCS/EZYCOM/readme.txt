Quick and Dirty Ezycom docs
---------------------------  
Written by: Shawn Highfield July 3, 2010

Here are the steps you should follow to get openedit working with ezy perfectly
which means - Multi users in the editor at a time, Displaying the correct message
area number etc.

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

1) Create node directories under your open!edit path ie: if open!edit is 
installed in c:/oedit you will create c:\oedit\node1, c:/oedit/node2, etc
for each node you run.

2) Copy openezy.exe to your main ezycom directory ie: c:\ezy

3) copy oedit.bat to your main ezycom directory ie: c:\ezy

4) Edit oedit.bat to reflect your system:
C:						- Change drive letter
cd\ezy						- Change to ezy directory
openezy.exe -N%1 				- Run ezyopen.exe with the current node number.
cd\ezy\oedit					- Change to open!edit dir
copy c:\ezy\msgtmp.%1 c:\ezy\oedit\node%1\msgtmp - Copy the temp file to the node directory in case you run a busy BBS
copy c:\ezy\node%1\door.sys c:\ezy\oedit\node%1  - copy the dropfile 
oedit.exe -N%1 -Pc:\ezy\oedit\node%1 -!          - Run cheepedit telling it where to find the files, the node your on, and suspend user's time limit
copy c:\ezy\oedit\node%1\msgtmp c:\ezy\msgtmp.%1 - After editing we are placing the file back where ezy wants it.
del c:\ezy\oedit\node%1\msgtmp			- Cleaning up.
del c:\ezy\oedit\node%1\msginf
del c:\ezy\oedit\node%1\door.sys

5)  Run oesetup.exe and configure as per the docs - Use generic BBS type for Ezy
 
6) Setup Ezycom to launch cedit.bat with the paramaters as per the docs.
ie: Ezycfg > Mail Areas > Misc
External Editor: c:\ezy\oedit.bat *N *D5 *M *!
(*N = Node number
 *D5 = Create a door.sys dropfile
 *M = Swap ezy out of memory
 *! = Suspend user's time while in open!edit
)
Old Style MSGTmp: No
